## instagram unfollow checker

Get notified via discord, when someone unfollows you on instagram. Uses [instagram-scrapper](https://github.com/realsirjoe/instagram-scraper)

## How to use
>NOTE : Create a new temporary bot instagram account to use with this script to avoid risks. This bot account can retrieve the followers of your real instagram account. (If you have a private account, make sure you follow your original account from your bor account first). DO NOT USE YOUR REAL INSTAGRAM ACCOUNT WITH THIS SCRIPT.

Follow these simple steps:
* Clone the repository - `git clone https://github.com/teja156/instagram-unfollow-checker`
* Install requirements.txt: `pip install --user -r requirements.txt`
* Configure your details: `python config.py`
* Finally, run `python unfollow_check.py`